# 416Project3
Animation in C++ with SDL 2.0.

All sprites and animations were created by Joseph Savold. Tracker framework was supplied by Dr. Malloy. 
